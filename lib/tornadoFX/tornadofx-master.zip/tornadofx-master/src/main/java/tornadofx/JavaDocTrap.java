package tornadofx;

/**
 * This class is here to make maven generate Javadocs.
 * Dokka generated documentation available in the GitHub repo:
 *
 * https://github.com/edvin/tornadofx
 */
public class JavaDocTrap {
}
